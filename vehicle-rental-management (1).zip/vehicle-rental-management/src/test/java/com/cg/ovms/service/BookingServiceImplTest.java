//package com.cg.ovms.service;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//
//import java.time.LocalDate;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.Mockito;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.cg.ovms.entity.Booking;
//import com.cg.ovms.entity.Customer;
//import com.cg.ovms.entity.Driver;
//import com.cg.ovms.entity.Vehicle;
//import com.cg.ovms.exception.RecordExistsException;
//import com.cg.ovms.exception.RecordNotFoundException;
//import com.cg.ovms.exception.SQLException;
//import com.cg.ovms.repository.IBookingRepository;
//import com.cg.ovms.repository.ICustomerRepository;
//import com.cg.ovms.repository.IVehicleRepository;
//
//@ExtendWith(SpringExtension.class)
//@SpringBootTest
//public class BookingServiceImplTest {
//	@MockBean
//	private IBookingRepository iBookingRepository;
//	@MockBean
//	private IVehicleRepository iVehicleRepository;
//
//	@MockBean
//	private ICustomerRepository iCustomerRepository;
//
//	@Autowired
//	private BookingServiceImpl bookingService;
//
//	// Creating Booking Object
//	public Booking createBooking() {
//
//		Driver driver = new Driver(1, "John", "Abraham", "9876543210", "john@gmail.com", "Mumbai", 100, "MH09DH1234");
//		Vehicle vehicle = new Vehicle(1, driver, "TN23KA9876", "AC", "Car", "White", "Chennai", "5", 10, 250);
//		Customer customer = new Customer(1, "Ram", "Agarwal", "9823874576", "richa@gmail.com", "Chennai");
//		Booking booking = new Booking(1, customer, vehicle, LocalDate.now(), LocalDate.now(), "Short Trip", 500, 20);
//		return booking;
//	}
//
//	// Creates List of Booking Entities
//	@SuppressWarnings("deprecation")
//	public List<Booking> createBookingList() {
//		List<Booking> bookingList = new ArrayList<Booking>();
//
//		Date date = new Date();
//		Driver driver = new Driver(1, "John", "Doe", "9876543210", "john@doe", "Chennai", 50, "DH123");
//		Vehicle vehicle = new Vehicle(1, driver, "TN23KA9876", "AC", "Car", "White", "Chennai", "25", 10, 25);
//		Customer customer = new Customer(1, "Richa", "D'souza", "9823874576", "ri@cha", "Chennai");
//
//		date.setDate(11);
//		date.setMonth(11);
//		date.setYear(2020); // 11th November 2020
//		Booking firstBooking = new Booking(1, customer, vehicle, LocalDate.now(), LocalDate.now(), "Short Trip", 500,
//				20);
//
//		date.setDate(8);
//		date.setMonth(9);
//		date.setYear(2020); // 8th September 2020
//		Booking secondBooking = new Booking(2, customer, vehicle, LocalDate.now(), LocalDate.now(), "Long Trip", 1000,
//				20);
//
//		date.setDate(11);
//		date.setMonth(10);
//		date.setYear(2020); // 11th October 2020
//		Booking thirdBooking = new Booking(3, customer, vehicle, LocalDate.now(), LocalDate.now(), "Short Trip", 300,
//				10);
//
//		bookingList.add(firstBooking);
//		bookingList.add(secondBooking);
//		bookingList.add(thirdBooking);
//
//		return bookingList;
//	}
//
//	// Checks for error if null is sent as parameter to Add Booking method
//	@Test
//	public void nullAddBooking() {
//		assertThrows(SQLException.class, () -> bookingService.addBooking(null), "Booking cannot be null");
//	}
//
//	// Checks for error if null is sent as parameter to Update Booking method
//	@Test
//	public void nullUpdateBooking() {
//		assertThrows(SQLException.class, () -> bookingService.updateBooking(null), "Booking cannot be null");
//	}
//
//	// Checks for error if 0 is sent as parameter to Cancel Booking method
//	@Test
//	public void nullCancelbooking() {
//		assertThrows(SQLException.class, () -> bookingService.cancelBooking(null), "BookingId cannot be 0");
//	}
//
//	// Checks for error if null is sent as parameter to viewBookingById method
//	@Test
//	public void checkNullViewBookingById() {
//		assertThrows(SQLException.class, () -> bookingService.viewBookingById(null), "Booking Id cannot be null");
//	}
//	
//	// Checks for error if null is sent as parameter to viewBookingByCustomer method
//	@Test
//	public void checkNullViewAllBookingByCustomer() {
//		assertThrows(SQLException.class, () -> bookingService.viewAllBookingByCustomer(null), "Customer Id cannot be null");
//	}
//
//	// Checks for error if null is sent as parameter to viewBookingByDate method
//	@Test
//	public void checkNullViewAllBookingyDate() {
//		assertThrows(SQLException.class, () -> bookingService.viewAllBookingByDate(null), "Date Cannot be null");
//	}
//
//	// Checks Add method when proper data is sent
//	@Test
//	public void checkProperAdd() {
//		Booking booking = createBooking();
//		booking.setBookingId(2);
//		Mockito.when(iVehicleRepository.existsById(booking.getVehicle().getVehicleId())).thenReturn(true);
//		Mockito.when(iCustomerRepository.existsById(booking.getCustomer().getCustomerId())).thenReturn(true);
//		
//		Mockito.when(iVehicleRepository.findById(booking.getVehicle().getVehicleId())).thenReturn(Optional.of(booking.getVehicle()));
//		Mockito.when(iCustomerRepository.findById(booking.getCustomer().getCustomerId())).thenReturn(Optional.of(booking.getCustomer()));
//		
//		Mockito.when(iBookingRepository.saveAndFlush(booking)).thenReturn(booking);
//		Mockito.when(iBookingRepository.findById(booking.getBookingId())).thenReturn(Optional.of(booking));
//		Booking returnBooking = bookingService.addBooking(booking);
//		
//		assertEquals(booking, returnBooking);
//	}
//
//	// Checks for error when booking already exists
//	@Test
//	public void checkBookingExistsAdd() {
//		Booking booking = createBooking();
//		Mockito.when(iVehicleRepository.existsById(booking.getVehicle().getVehicleId())).thenReturn(true);
//		Mockito.when(iCustomerRepository.existsById(booking.getCustomer().getCustomerId())).thenReturn(true);
//		
//		Mockito.when(iVehicleRepository.findById(booking.getVehicle().getVehicleId())).thenReturn(Optional.of(booking.getVehicle()));
//		Mockito.when(iCustomerRepository.findById(booking.getCustomer().getCustomerId())).thenReturn(Optional.of(booking.getCustomer()));
//		
//		Mockito.when(iBookingRepository.saveAndFlush(booking)).thenReturn(booking);
//		Mockito.when(iBookingRepository.existsById(booking.getBookingId())).thenReturn(true);
//		
//		assertThrows(RecordExistsException.class, () -> bookingService.addBooking(booking),
//				"Duplicate Record Found");
//	}
//
//	// Checks for error in case booking is not added to database
//	@Test
//	public void checkBookingNotAdded() {		
//		Booking booking = createBooking();
//		Mockito.when(iVehicleRepository.existsById(booking.getVehicle().getVehicleId())).thenReturn(true);
//		Mockito.when(iCustomerRepository.existsById(booking.getCustomer().getCustomerId())).thenReturn(true);
//		
//		Mockito.when(iVehicleRepository.findById(booking.getVehicle().getVehicleId())).thenReturn(Optional.of(booking.getVehicle()));
//		Mockito.when(iCustomerRepository.findById(booking.getCustomer().getCustomerId())).thenReturn(Optional.of(booking.getCustomer()));
//		
//		Mockito.when(iBookingRepository.saveAndFlush(booking)).thenReturn(booking);
//		Mockito.when(iBookingRepository.findById(booking.getBookingId())).thenReturn(Optional.of(booking));
//	}
//
//	// Checks Update method for proper input
//	@Test
//	public void checkProperUpdate() {
//		Booking booking = createBooking();
//		
//		Mockito.when(iVehicleRepository.existsById(booking.getVehicle().getVehicleId())).thenReturn(true);
//		Mockito.when(iCustomerRepository.existsById(booking.getCustomer().getCustomerId())).thenReturn(true);
//		
//		Mockito.when(iVehicleRepository.findById(booking.getVehicle().getVehicleId())).thenReturn(Optional.of(booking.getVehicle()));
//		Mockito.when(iCustomerRepository.findById(booking.getCustomer().getCustomerId())).thenReturn(Optional.of(booking.getCustomer()));
//		
//		Mockito.when(iBookingRepository.existsById(booking.getBookingId())).thenReturn(true);
//		Mockito.when(iBookingRepository.save(booking)).thenReturn(null);
//		Mockito.when(iBookingRepository.findById(booking.getBookingId())).thenReturn(Optional.of(booking));
//		Booking returnBooking = bookingService.updateBooking(booking);
//		
//		assertEquals(returnBooking, booking);
//	}
//
//	// Checks for error if data is not updated in database
//	@Test
//	public void checkBookingNotUpdated() {
//		Booking booking = createBooking();
//		
//		Mockito.when(iVehicleRepository.existsById(booking.getVehicle().getVehicleId())).thenReturn(true);
//		Mockito.when(iCustomerRepository.existsById(booking.getCustomer().getCustomerId())).thenReturn(true);
//		
//		Mockito.when(iVehicleRepository.findById(booking.getVehicle().getVehicleId())).thenReturn(Optional.of(booking.getVehicle()));
//		Mockito.when(iCustomerRepository.findById(booking.getCustomer().getCustomerId())).thenReturn(Optional.of(booking.getCustomer()));
//		
//		Mockito.when(iBookingRepository.existsById(booking.getBookingId())).thenReturn(true);
//		Mockito.when(iBookingRepository.save(booking)).thenReturn(null);
//
//		Mockito.when(iBookingRepository.findById(booking.getBookingId())).thenReturn(Optional.ofNullable(null));
//		
//		assertThrows(SQLException.class, () -> bookingService.updateBooking(booking), "Booking updation did not happened");
//	}
//
//	// Checks Cancel Booking method for proper data
//	@Test
//	public void checkProperCancelBooking() {
//		Booking booking = createBooking();
//		Integer bookingId = 1;
//		
//		Mockito.when(iBookingRepository.existsById(booking.getBookingId())).thenReturn(true);
//		List<Booking> bookingList = createBookingList();
//		
//		Mockito.when(iBookingRepository.findAll()).thenReturn(bookingList);
//		assertEquals(bookingList, bookingService.cancelBooking(bookingId));
//	}
//	
//	public void checkBookingNotCancel() {
//		Booking booking = createBooking();
//		Integer bookingId = 1;
//		
//		Mockito.when(iBookingRepository.existsById(booking.getBookingId())).thenReturn(false);
//		List<Booking> bookingList = createBookingList();
//		
//		Mockito.when(iBookingRepository.findAll()).thenReturn(bookingList);
//		assertThrows(RecordNotFoundException.class, () -> bookingService.cancelBooking(bookingId), "Booking with the given id doesn't exists");
//	}
//}

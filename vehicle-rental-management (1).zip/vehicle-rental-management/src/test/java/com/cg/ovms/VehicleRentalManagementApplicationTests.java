//package com.cg.ovms;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class VehicleRentalManagementApplicationTests {
//	
//	@Test
//	void contextLoads() {
//	}
//
//}
//package com.cg.ovms.service;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//
//import java.time.LocalDate;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.Mockito;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.cg.ovms.entity.Booking;
//import com.cg.ovms.entity.Customer;
//import com.cg.ovms.entity.Driver;
//import com.cg.ovms.entity.Payment;
//import com.cg.ovms.entity.Vehicle;
//import com.cg.ovms.exception.RecordExistsException;
//import com.cg.ovms.exception.RecordNotFoundException;
//import com.cg.ovms.exception.SQLException;
//import com.cg.ovms.repository.IPaymentRepository;
//
//@ExtendWith(SpringExtension.class)
//@SpringBootTest
//public class PaymentServiceImplTest {
//	
//	@MockBean
//    private IPaymentRepository paymentRepository;
//
//    @Autowired
//    private PaymentServiceImpl paymentService;
//    
//    //Creating Payment Object
//    public Payment createPayment() {
//    		Driver driver = new Driver(1, "John", "Doe", "9876543210", "john@doe", "Chennai", 50, "DH123");
//    		Vehicle vehicle = new Vehicle(1, driver, "TN23KA9876", "AC", "Car", "White", "Chennai", "25", 10, 25);
//    		Customer customer = new Customer(1, "Richa", "D'souza", "9823874576", "ri@cha", "Chennai");
//    		Booking booking = new Booking(1, customer, vehicle, LocalDate.now(), LocalDate.now(), "Short Trip", 500, 20);
//    		Payment payment = new Payment(1, "Cash", new Date(), booking, "Paid");
//    		return payment;
//    }
//
//	public List<Payment> createPaymentList() {
//    	List<Payment> paymentList = new ArrayList<Payment>();
//    	
//    	Date date = java.sql.Date.valueOf("2022-03-24");
//    	
//    	
//    	
//    	Driver driver = new Driver(1,"John", "Doe", "9876543210", "john@doe", "Chennai", 50, "DH123");
//    	Vehicle vehicle = new Vehicle(1, driver, "TN23KA9876", "AC", "Car", "White", "Chennai", "25", 10, 25);
//    	Customer customer = new Customer(1, "Richa", "D'souza", "9823874576", "ri@cha", "Chennai");
//    	
//    	
//    	//11th November 2020
//    	Booking firstBooking = new Booking(1, customer, vehicle, LocalDate.now(), LocalDate.now(), "Short Trip", 500, 20);
//    	Payment firstPayment = new Payment(1, "Cash",date, firstBooking, "Paid");
//    	
//    	Booking secondBooking = new Booking(2, customer, vehicle, LocalDate.now(), LocalDate.now(), "Long Trip", 1000, 20);
//    	Payment secondPayment = new Payment(2, "Credit", date, secondBooking, "Paid");
//
//    	
//    	Booking thirdBooking = new Booking(3, customer, vehicle, LocalDate.now(), LocalDate.now(), "Short Trip", 300, 10);
//    	Payment thirdPayment = new Payment(3, "Cash", date, thirdBooking, "Paid");
//    	
//    	paymentList.add(firstPayment);
//    	paymentList.add(secondPayment);
//    	paymentList.add(thirdPayment);
//    	
//    	return paymentList;
//    }
//
//    //Checks for error if null is sent as parameter to Add Payment method
//    @Test
//    public void nullAddPayment() {
//    	assertThrows(SQLException.class, () -> paymentService.addPayment(null), "Payment can't be Null");
//    }
//
//   
//    //Checks for error if 0 is sent as parameter to Cancel Payment method
//    @Test
//    public void nullCancelPayment() {
//    	assertThrows(RecordNotFoundException.class, () -> paymentService.cancelPayment(0), "No Data Found");
//    }
//    
//    //Checks for error if null is sent as parameter to viewPaymentByBooking method
//    @Test
//	public void checkNullViewPaymentByBooking() {	
//		assertThrows(RecordNotFoundException.class, () -> paymentService.viewPaymentByBookingId(0), "BookingId can't be Null");
//    }
//    
//    //Checks for error if null is sent as parameter to calculateMonthlyRevenue method
//    @Test
//	public void checkNullCalculateMonthlyRevenue() {	
//    	assertThrows(SQLException.class, () -> paymentService.calculateMonthlyRevenue(null, null), "Date can't be Null");
//    }
//
//
//    //Checks Add method when proper data is sent
//    @Test
//    public void checkProperAdd() {    
//    	Payment payment = createPayment();   
//    	payment.getBooking().setBookingId(2);
//    	
//    	Payment returnPayment = payment;
//    	
//    	Mockito.when(paymentRepository.findByBooking(payment.getBooking())).thenReturn(null);
//    	Mockito.when(paymentRepository.saveAndFlush(payment)).thenReturn(returnPayment);
//    	 returnPayment = paymentService.addPayment(payment);
//    	assertEquals(payment, returnPayment);
//    }
//
//    //Checks for error when booking already exists 
//    @Test
//    public void checkBookingExistsAdd() {					
//    	Payment payment = createPayment();   
//    	payment.setPaymentId(0);
//    	Mockito.when(paymentRepository.findByBooking(payment.getBooking())).thenReturn(payment);
//    	assertThrows(RecordExistsException.class, () -> paymentService.addPayment(payment), 
//    			"Payment already exists for this booking. Please update payment.");
//    }
//
//    //Checks for error in case payment is not added to database
//    @Test
//    public void checkPaymentNotAdded() {		
//    	Payment payment = createPayment();   
//    	payment.setPaymentId(0);
//    	Mockito.when(paymentRepository.findByBooking(payment.getBooking())).thenReturn(null);
//    	Mockito.when(paymentRepository.saveAndFlush(payment)).thenReturn(null);
//    	assertThrows(SQLException.class, () -> paymentService.addPayment(payment), "Payment Not Added");
//    }
//
//    @Test
//    public void checkProperDelete() {
//    	Payment payment = createPayment(); 
//    	int paymentId = 1;
//    	
//    	Mockito.when(paymentRepository.findById(paymentId)).thenReturn(Optional.of(payment));
//    	Mockito.when(paymentRepository.findByBooking(payment.getBooking())).thenReturn(payment);
//    	Mockito.when(paymentRepository.save(payment)).thenReturn(payment);
//		payment = paymentService.cancelPayment(1);
//		assertEquals("Cancelled", payment.getPaymentStatus());
//    }
//    
//    //Checks for error if invalid Id is sent to Cancel payment method
//    @Test
//    public void checkRecordDoesNotExistDelete() {
//    	int paymentId = 1;
//    	Mockito.when(paymentRepository.findById(paymentId)).thenReturn(Optional.ofNullable(null));
//    	assertThrows(RecordNotFoundException.class, () -> paymentService.cancelPayment(paymentId), 
//    			"Payment doesn't exist in database. Add payment first.");
//    }
//     
//    //Checks for error in cancel payment when Booking does not exist
//    @Test
//    public void checkBookingDoesNotExistDelete() {
//    	Payment payment = createPayment(); 
//    	int paymentId = 1;  	
//    	Mockito.when(paymentRepository.findById(paymentId)).thenReturn(Optional.of(payment));
//    	Mockito.when(paymentRepository.findByBooking(payment.getBooking())).thenReturn(null);
//    	assertThrows(RecordNotFoundException.class, () -> paymentService.cancelPayment(paymentId), "Data Not Found");
//    }
//    
//    //Checks for error if no records exist in database
//    @Test						
//	public void checkViewAllPaymentNoRecord() {	
//    	Mockito.when(paymentRepository.findAll()).thenReturn(new ArrayList<Payment>());
//		assertThrows(RecordNotFoundException.class, () -> paymentService.viewAllPayments(), "No Data Found");
//    }
//     
//
//    //Checks for view payment if payment doesn't exist
//	@Test
//	public void checkViewPaymentByNonExistentBooking() {
//		Payment payment=createPayment();
//   	    	Mockito.when(paymentRepository.findByBooking(payment.getBooking())).thenReturn(null);
//    	assertThrows(RecordNotFoundException.class, () -> paymentService.viewPaymentByBookingId(payment.getBooking().getBookingId()), "No Data Found");
//   }
//}
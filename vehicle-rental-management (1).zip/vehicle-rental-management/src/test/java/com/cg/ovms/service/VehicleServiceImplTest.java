//package com.cg.ovms.service;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.Mockito;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.cg.ovms.entity.Driver;
//import com.cg.ovms.entity.Vehicle;
//import com.cg.ovms.exception.RecordNotFoundException;
//import com.cg.ovms.repository.IVehicleRepository;
//
//@ExtendWith(SpringExtension.class)
//@SpringBootTest
//public class VehicleServiceImplTest {
//	@MockBean
//	private IVehicleRepository vehicleRepository;
//	
//	@Autowired
//	private VehicleServiceImpl vehicleService;
//	
//	//Creating Vehicle Object
//	public Vehicle createVehicle() {
//		Driver driver = new Driver(1, "John", "Doe", "9876543210", "john@doe", "Chennai", 50, "DH123");
//		Vehicle vehicle = new Vehicle(1, driver, "TN23KA9876", "AC", "Car", "White", "Chennai", "25", 10, 25);
//		return vehicle;
//	}
//	
//	//Creates List of Vehicle Entities
////	@SuppressWarnings("deprecation")
//	public List<Vehicle> createVehicleList() {
//		List<Vehicle> vehicleEntityList = new ArrayList<Vehicle>();
//		
////		Date date = new Date();
//		
//		//NEW DRIVER FOR EVERY NEW VEHICLE??
//		
////		date.setDate(11);
////		date.setMonth(11);
////		date.setYear(2020);		
//		Driver firstDriver = new Driver(1,"John", "Doe", "9876543210", "john@doe", "Chennai", 50, "DH123");
//		Vehicle firstVehicle = new Vehicle(1, firstDriver, "TN23KA9876", "AC", "Car", "White", "Chennai", "25", 10, 25);
//		
////		date.setDate(8);
////		date.setMonth(9);
////		date.setYear(2020);
//		Driver secondDriver = new Driver(2,"Richard", "Roe", "9872543411", "richard@roe", "Mumbai", 100, "UP456");
//		Vehicle secondVehicle = new Vehicle(2, secondDriver, "SB45HI8756", "NON-AC", "Car", "Black", "Mumbai", "10", 15, 30);
//		
////		date.setDate(11);
////		date.setMonth(10);
////		date.setYear(2020);
//		Driver thirdDriver = new Driver(3,"Steven", "Sinclair", "9472443432", "steven@sinclair", "Delhi", 80, "WB789");
//		Vehicle thirdVehicle = new Vehicle(3, thirdDriver, "FH23IA6872", "AC", "MiniVan", "Grey", "Delhi", "20", 20, 20);
//		
//		vehicleEntityList.add(firstVehicle);
//		vehicleEntityList.add(secondVehicle);
//		vehicleEntityList.add(thirdVehicle);
//		
//		return vehicleEntityList;
//	}
//	
//	//Checks for error if null is sent as parameter to Add Vehicle Method
//	@Test
//	public void nullAddVehicle() {
//		assertThrows(RecordNotFoundException.class, () -> vehicleService.addVehicle(null), "Vehicle cannot be null");
//	}
//	
//	
//	//Checks for error if null is sent as parameter to Remove Vehicle Method
//	@Test
//	public void nullremoveVehicle() {
//		assertThrows(RecordNotFoundException.class, () -> vehicleService.removeVehicle(null), "Vehicle input can't be Null");
//	}
//	
//	//Checks for error if null is sent as parameter to View Vehicle Method
//	@Test
//	public void nullviewVehicle() {
//		assertThrows(RecordNotFoundException.class, () -> vehicleService.viewVehicle(null), "Vehicle cannot be null");
//	}
//	
//	//Checks for error if null is sent as parameter to Update Vehicle Method
//	@Test
//	public void nullupdateVehicle() {
//		assertThrows(RecordNotFoundException.class, () -> vehicleService.updateVehicle(null), "Vehicle cannot be null");
//	}
//	
//	//Checks for error if null is sent as parameter to View All Vehicle Method
//	@Test
//	public void nullviewAllVehicle() {
//		assertThrows(RecordNotFoundException.class, () -> vehicleService.viewAllVehicle(), "Vehicle input can't be Null");
//	}
//
//
//
//
//
//	//Checks Add method when proper data is sent
//	@Test
//	public void checkProperAddVehicle() {    
//  	
//	Vehicle vehicle = createVehicle();
//	
//  	Mockito.when(vehicleRepository.saveAndFlush(vehicle)).thenReturn(vehicle);
//  	Mockito.when(vehicleRepository.findById(vehicle.getVehicleId())).thenReturn(Optional.of(vehicle));
//  	Vehicle vehicle1 = vehicleService.addVehicle(vehicle);
//  	assertEquals(vehicle, vehicle1);
//	}
//	
//	
//	//Checks for error while removing the data
//	//@Test
//	public void checkProperRemoveVehicle() {    
//	  	
//		Vehicle vehicle = createVehicle();
//		
//	  	Mockito.when(vehicleRepository.findById(vehicle.getVehicleId())).thenReturn(Optional.of(vehicle));
//	  	
//	  	List<Vehicle> vehicleList = vehicleService.removeVehicle(vehicle.getVehicleId());
//	  	Vehicle vehicle2 = vehicleList.get(0);
//	  	
//	  	assertEquals(vehicle, vehicle2);
//	}
//	
//	//Checks correct vehicle is being viewed
//		@Test
//		public void checkProperViewVehicle() {    
//	  	
//		Vehicle vehicle = createVehicle();
//		
//	  	Mockito.when(vehicleRepository.findById(vehicle.getVehicleId())).thenReturn(Optional.of(vehicle));
//	  	Vehicle vehicle2 = vehicleService.viewVehicle(vehicle);
//	  	assertEquals(vehicle, vehicle2);
//		}
//		
//	//Checks correct vehicle is being updated
//		@Test
//		public void checkProperUpdateVehicle() {    
//	  	
//		Vehicle vehicle = createVehicle();
//		
//	  	Mockito.when(vehicleRepository.findById(vehicle.getVehicleId())).thenReturn(Optional.of(vehicle));
//	  	Vehicle vehicle3 = vehicleService.updateVehicle(vehicle);
//	  	assertEquals(vehicle, vehicle3);
//		}
//		
//	//Checks if the records are present in database
//		@Test
//		public void checkProperViewAllVehicle() {    
//		  	
//			Vehicle vehicle = createVehicle();
//			List<Vehicle> vehicleEntityList = createVehicleList();
//		  	Mockito.when(vehicleRepository.findAll()).thenReturn(vehicleEntityList);
//		  	
//		  	List<Vehicle> vehicleList = vehicleService.viewAllVehicle();
//		  	
//		  	assertEquals(vehicle, vehicleList.size());
//		}
//}

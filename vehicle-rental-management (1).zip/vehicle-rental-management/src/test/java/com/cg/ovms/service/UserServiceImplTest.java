package com.cg.ovms.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cg.ovms.entity.User;
import com.cg.ovms.exception.ApplicationException;
import com.cg.ovms.exception.UserNotFoundException;
import com.cg.ovms.repository.IUserRepository;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class UserServiceImplTest {
	
	@MockBean
	private IUserRepository iUserRepository;
	
	@Autowired
	private UserServiceImpl userService;
	
	//creating user object
	public User createUser( ) {
		User user = new User("aman@gmail.com","aman1234","customer");
		return user;
	}

	
	// User Null Testing
	@Test
	public void nullSignIn() {
		assertThrows(UserNotFoundException.class, () -> userService.signIn(null), "user cannot be null");
	}
	
	@Test
	public void nullAddUser() {
		assertThrows(UserNotFoundException.class, () -> userService.addUser(null), "user cannot be null");
	}
	
	@Test
	public void nullUpdatePassword() {
		assertThrows(UserNotFoundException.class, () -> userService.updatePassword(null,""), "Invalid User - resend with correct details");
	}
	
	@Test
	public void nullRemoveUser() {
		assertThrows(UserNotFoundException.class, () -> userService.removeUser(null), "Invalid User - resend with correct details");
	}
	
	@Test
	public void nullSignOutUser() {
		assertThrows(UserNotFoundException.class, () -> userService.signOut(null), "Invalid User - resend with correct details");
	}
	
	// check sign in successful if all details correctly entered
	@Test
	public void checkSignIn() {
		User user = createUser();
		Mockito.when(iUserRepository.findById(user.getUserId())).thenReturn(Optional.of(user));
    	User user1 = userService.signIn(user);
    	assertEquals(user, user1);
	}
	
	@Test
	public void checkaddUser() {
		User user = createUser();
		Mockito.when(iUserRepository.findById(user.getUserId())).thenReturn(Optional.ofNullable(null));
		Mockito.when(iUserRepository.save(user)).thenReturn(user);
    	User user1 = userService.addUser(user);
    	assertEquals(user, user1);
	}
	
	@Test
	public void checkUpdatePassword() {
		User userNew = createUser();
		String password = "erty4321";
		userNew.setPassword(password);
		User userOld = createUser();
		Mockito.when(iUserRepository.findById(userOld.getUserId())).thenReturn(Optional.of(userOld));
		Mockito.when(iUserRepository.save(userNew)).thenReturn(userNew);
		User user1;
		try {
			user1 = userService.updatePassword(userOld,password);
			assertEquals(userNew.getPassword(), user1.getPassword());
		} catch (UserNotFoundException e) {
			assertEquals(e.getMessage(),"Invalid User - resend with correct details");
		} catch (ApplicationException e) {
			assertEquals(e.getMessage(),"Password Updation Unsuccessful");
		}
	}
	
	@Test
	public void checkRemoveUser() {
		User user = createUser();
		Mockito.when(iUserRepository.findById(user.getUserId())).thenReturn(Optional.of(user));
    	User user1 = userService.removeUser(user);
    	assertEquals(user, user1);
	}
	
	@Test
	public void checkSignOut() {
		User user = createUser();
		Mockito.when(iUserRepository.findById(user.getUserId())).thenReturn(Optional.of(user));
    	User user1 = userService.signOut(user);
    	assertEquals(user, user1);
	}
	
}
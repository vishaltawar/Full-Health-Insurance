package com.cg.ovms.service;

import java.util.*;

import com.cg.ovms.entity.Driver;

public interface DriverService {
	public Driver addDriver(Driver d);
	public List<Driver> getAllDrivers();
	public Driver getDriverById(int id);
	public Driver updateDriverById(Driver d,int id);
	public Driver deleteDriverById(int id);
}

package com.cg.ovms.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="payment")
public class Payment implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="payment_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int paymentId;
	
	@NotBlank(message = "payment mode value cannot be null")
    @Column(name="payment_mode")
	private String paymentMode;
	
	@NotNull(message = "payment date cannot be null")
	@PastOrPresent
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name="payment_date")
	private Date paymentDate;
	
	@NotBlank(message = "payment status cannot be null")
	@Column(name="payment_status")
	private String paymentStatus;
	
	@NotNull(message = "booking details cannot be null")
	@OneToOne(cascade = CascadeType.REMOVE)
	@JoinColumn(name="booking_id")
	private Booking booking;

	public Payment() {
		
	}
	
	public Payment(int paymentId, String paymentMode, Date paymentDate, Booking booking, String paymentStatus) {
		super();
		this.paymentId = paymentId;
		this.paymentMode = paymentMode;
		this.paymentDate = paymentDate;
		this.booking = booking;
		this.paymentStatus = paymentStatus;
	}

	public void setPaymentId(Integer paymentId) { this.paymentId = paymentId; }
	
	public int getPaymentId() { return paymentId; }

	public String getPaymentMode() { return paymentMode; }

	public void setPaymentMode(String paymentMode) { this.paymentMode = paymentMode; }

	public Date getPaymentDate() { return paymentDate;}

	public void setPaymentDate(Date paymentDate) { this.paymentDate = paymentDate; }

	public Booking getBooking() { return booking; }

	public void setBooking(Booking booking) { this.booking = booking; }

	public String getPaymentStatus() { return paymentStatus; }

	public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

	@Override
	public String toString() {
		return "PaymentEntity [paymentId=" + paymentId + ", paymentMode=" + paymentMode + ", paymentDate=" + paymentDate
				+ ", paymentStatus=" + paymentStatus + ", booking=" + booking + "]";
	}
}
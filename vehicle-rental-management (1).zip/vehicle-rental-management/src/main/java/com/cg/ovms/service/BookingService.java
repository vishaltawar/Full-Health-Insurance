package com.cg.ovms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.ovms.entity.Booking;
import com.cg.ovms.exception.RecordExistsException;
import com.cg.ovms.exception.SQLException;

@Service
public interface BookingService {

	public Booking addBooking(Booking booking)throws SQLException, RecordExistsException;
	public List<Booking> cancelBooking(Integer bookingId);
	public Booking updateBooking(Booking booking);
	public Booking viewBookingById(Integer bookingId);
	public List<Booking> viewAllBookings();
	public List<Booking> viewAllBookingByCustomer(Integer customerId);
	public List<Booking> viewAllBookingByDate(String bookingDate);
	
	public double calculatePaymentPerDay(Booking booking, int days);	
}

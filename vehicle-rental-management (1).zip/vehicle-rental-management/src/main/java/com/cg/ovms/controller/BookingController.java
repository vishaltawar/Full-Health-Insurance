package com.cg.ovms.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ovms.entity.Booking;
import com.cg.ovms.service.BookingService;

@CrossOrigin("*")
@RestController
@RequestMapping("/ovms")
public class BookingController {

	private static final Logger log = LogManager.getLogger(BookingController.class);
	
	@Autowired
	private BookingService bookingService;
	
	//Adding a New Booking
	@PostMapping("/bookings")
	public ResponseEntity<Booking> addBooking(@Valid @RequestBody Booking booking){
		log.info("Add Booking Contoller Started");
		Booking returnBooking = bookingService.addBooking(booking);
		log.info("Add Booking Contoller Ended");
		return new ResponseEntity<>(returnBooking, HttpStatus.OK);
	}
	
	//Canceling a Booking
	@DeleteMapping("/bookings/{bookingId}")
	public ResponseEntity<List<Booking>> cancelBooking(@Valid @PathVariable("bookingId")Integer bookingId){
		log.info("Cancel Booking Contoller Started");
		List<Booking> allBooking = bookingService.cancelBooking(bookingId);
		log.info("Cancel Booking Contoller Ended");
		return new ResponseEntity<>(allBooking, HttpStatus.OK);
	}
	
	//Updating a Booking
	@PutMapping("/bookings")
	public ResponseEntity<Booking> updateBooking(@Valid @RequestBody Booking booking){
		log.info("Update Booking Contoller Started");
		Booking returnBooking= bookingService.updateBooking(booking);
		log.info("Update Booking Contoller Started");
		return new ResponseEntity<>(returnBooking, HttpStatus.OK);
	}
	
	//Viewing a Booking by Booking ID
	@GetMapping("/booking/{bookingId}")
	public ResponseEntity<Booking> viewBooking(@Valid @PathVariable("bookingId")Integer bookingId){
		log.info("View Booking Contoller Started");
		Booking returnBooking= bookingService.viewBookingById(bookingId);
		log.info("View Booking Contoller Ended");
		return new ResponseEntity<>(returnBooking, HttpStatus.OK);
	}
	
	//View all Bookings by CustomerId
	@GetMapping("/bookingsby/{customerId}")
	public ResponseEntity<List<Booking>> viewAllBooking(@Valid @PathVariable("customerId")Integer customerId){
		
		log.info("View All Booking Contoller Started");
		List<Booking> allBooking = bookingService.viewAllBookingByCustomer(customerId);
		log.info("View All Booking Contoller Ended");
		return new ResponseEntity<>(allBooking, HttpStatus.OK);
	}
	
	//View all Bookings by Booking Date
	@GetMapping("/bookings/{bookingDate}")
	public ResponseEntity<List<Booking>> viewAllBookingByDate(@Valid @PathVariable("bookingDate") String bookingDate){
		log.info("View All Bookings By Date Contoller Started");
		List<Booking> allBooking = bookingService.viewAllBookingByDate(bookingDate);
		log.info("View All Bookings By Date Contoller Ended");
		return new ResponseEntity<>(allBooking, HttpStatus.OK);
	}
	
	//View all Bookings
	@GetMapping("/bookings")
	public ResponseEntity<List<Booking>> viewAllBookings(){
		log.info("View All Bookings Contoller Started");
		List<Booking> allBooking = bookingService.viewAllBookings();
		log.info("View All Bookings Contoller Ended");
		return new ResponseEntity<>(allBooking, HttpStatus.OK);
	}
}
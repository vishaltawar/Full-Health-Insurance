package com.cg.ovms.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ovms.entity.Customer;
import com.cg.ovms.exception.RecordNotFoundException;
import com.cg.ovms.service.CustomerService;

@CrossOrigin("*")
@RestController
@RequestMapping("/ovms")
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	static Logger log = Logger.getLogger(CustomerController.class.getName());

	@PostMapping("/customer")
	public ResponseEntity<Customer> addCustomer(@Valid @RequestBody Customer customer) {
		
		log.info("Controller layer - Entry - addCustomer");
		customer = customerService.addCustomer(customer);
		log.info("Controller layer - Exit - addCustomer");
		return new ResponseEntity<>(customer, HttpStatus.OK);
	}

	@DeleteMapping("/customer/{customerId}")
	public ResponseEntity<Customer> removeCustomer(@PathVariable("customerId") Integer customerId) {
		
		log.info("Controller layer - Entry - removeCustomer");
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		customer = customerService.removeCustomer(customer);
		log.info("Controller layer - Exit - removeCustomer");
		return new ResponseEntity<>(customer, HttpStatus.OK);
	}

	@GetMapping("/customer/{customerId}")
	public ResponseEntity<Customer> viewCustomerBycustomerId(@PathVariable("customerId") Integer customerId)
			throws RecordNotFoundException { 
		
		log.info("Controller layer - Entry - viewCustomerBycustomerId");
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		Customer customer1 = customerService.viewCustomer(customer);
		log.info("Controller layer - Exit - viewCustomerByCustomerId");
		return new ResponseEntity<>(customer1, HttpStatus.OK);
	}
	
	@GetMapping("/customer/email/{emailId}")
	public ResponseEntity<Customer> viewCustomerByemailId(@PathVariable("emailId") String emailId)
			throws RecordNotFoundException { 
		
		log.info("Controller layer - Entry - viewCustomerByemailId");
		Customer customer1 = customerService.viewCustomerByemailId(emailId);
		log.info("Controller layer - Exit - viewCustomerByemailId");
		return new ResponseEntity<>(customer1, HttpStatus.OK);
	}

	@PutMapping("/customer")
	public ResponseEntity<Customer> updateCustomer(@Valid @RequestBody Customer customer)
			throws RecordNotFoundException {

		customer = customerService.updateCustomer(customer);
		return new ResponseEntity<>(customer, HttpStatus.OK);
	}

	@GetMapping("/viewcustomers")
	public ResponseEntity<List<Customer>> viewAllCustomer() throws RecordNotFoundException {

		List<Customer> customerList = customerService.viewAllCustomer();
		return new ResponseEntity<>(customerList, HttpStatus.OK);
	}

	@GetMapping("/viewcustomers/{location}")
	public ResponseEntity<List<Customer>> customersByLocation(@PathVariable("location") String location) throws RecordNotFoundException {

		List<Customer> customerList = customerService.viewAllCustomersByLocation(location);
		return new ResponseEntity<>(customerList, HttpStatus.OK);
	}
}
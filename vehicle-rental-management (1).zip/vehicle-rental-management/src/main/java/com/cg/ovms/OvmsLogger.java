package com.cg.ovms;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import java.time.LocalDateTime;

public class OvmsLogger {
	private OvmsLogger() {
		
	}
    private static final Logger logger = LogManager.getLogger(OvmsLogger.class);
    public static String info(String string) {
    	String message = LocalDateTime.now().toString()+" :: INFO :: "+string;
        logger.info(message);
        return message;
    }
}




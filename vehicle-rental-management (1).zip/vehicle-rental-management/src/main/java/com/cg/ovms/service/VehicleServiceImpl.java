package com.cg.ovms.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ovms.entity.Vehicle;
import com.cg.ovms.exception.SQLException;
import com.cg.ovms.exception.RecordNotFoundException;
import com.cg.ovms.repository.IVehicleRepository;


@Service
public class VehicleServiceImpl implements VehicleService {

	 static Logger log = Logger.getLogger(VehicleServiceImpl.class.getName());

	@Autowired
	private IVehicleRepository vehicleDao;
	
	// addVehicle Service Implementation
	@Override
	public Vehicle addVehicle(Vehicle vehicle) throws RecordNotFoundException, SQLException
	{
		log.info("Add Vehicle Service Started");
		if(Objects.isNull(vehicle)) {
			throw new RecordNotFoundException("Vehicle cannot be null");
		}
		vehicle = vehicleDao.saveAndFlush(vehicle);
		Optional<Vehicle> vehicles = vehicleDao.findById(vehicle.getVehicleId());
		
		if (!vehicles.isPresent()) 
		{
			log.error("exception exists for adding vehicle in service layer");
			throw new SQLException("Vehicle was not added");
		}

		log.info("Add Vehicle Service Completed");
		
		return vehicle;
	}

	//removeVehicle Service Implementation
	@Override
	public List<Vehicle> removeVehicle(Integer vehicleId) throws RecordNotFoundException{

		log.info("removeVehicle service started");
		if (vehicleId == null) {
			throw new RecordNotFoundException("Vehicle Id cannot be null");
		}
		Optional<Vehicle> remove = vehicleDao.findById(vehicleId);

		if (!remove.isPresent()) {
			log.error("exception exists for removing vehicle in service layer");
			throw new RecordNotFoundException("Booking with the given id does not exist");
			
		}

		vehicleDao.deleteById(vehicleId);
		List<Vehicle> vehicleList = vehicleDao.findAll();

		if (vehicleList == null || vehicleList.isEmpty()) {
			log.warn("no vehicles avialble after cancelling in the service layer");
			throw new RecordNotFoundException("No Vehicles avaliable");
		}

		log.info("remove the vehicle service completed");
		return vehicleList;
	}
	
	// ViewVehicle Service Implementation
	@Override
	public Vehicle viewVehicle(Vehicle vehicle)
	{

		log.info("View Vehicle Service Started");
		if(vehicle==null) {
			throw new RecordNotFoundException("Vehicle cannot be null");
		}
	
		Optional<Vehicle> vehicles = vehicleDao.findById(vehicle.getVehicleId());
		

		if (!vehicles.isPresent())
		{
			log.error("exception in view VehicleById in service layer");
			throw new RecordNotFoundException("Vehicle with id " + vehicle.getVehicleId() + " not found");
		}
		
		log.info("view Vehicle service completed");
		return vehicle;
	}

	// UpdateVehicle Service Implementation
	@Override
	public Vehicle updateVehicle(Vehicle vehicle) {

		log.info("Update Vehicle Service Started");
		if(Objects.isNull(vehicle)) {
			throw new RecordNotFoundException("Vehicle cannot be null");
		}
		
		
		Optional<Vehicle> vehicleObj = vehicleDao.findById(vehicle.getVehicleId());

		if (!vehicleObj.isPresent())
		{
			log.error("exception of update vehicle in service layer");
			throw new RecordNotFoundException("Vehicle with id" + vehicle.getVehicleId() + " not found");
		}
		 
		vehicle = vehicleDao.save(vehicle);
		
		vehicleObj = vehicleDao.findById(vehicle.getVehicleId());

		if (!vehicleObj.isPresent())
		{
			log.error("exception of update vehicle in service layer");
			throw new RecordNotFoundException("Updated Vehicle not added");
		}
		log.info("Update Vehicle service completed");
		return vehicle;
	}

	// ViewAllVehicle Service Implementation
	@Override
	public List<Vehicle> viewAllVehicle() {

		log.info("View All Vehicle service started");

		List<Vehicle> vehicleList = vehicleDao.findAll();
		
		if(vehicleList.isEmpty()) {
			log.error("exception of viewAllVehicle in service layer");
			throw new RecordNotFoundException("No Vehicles available");
		}
		
		log.info("View All Vehicle service completed");
		return vehicleList;

	}
}
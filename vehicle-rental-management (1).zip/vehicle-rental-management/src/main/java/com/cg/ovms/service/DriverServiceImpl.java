package com.cg.ovms.service;

import java.util.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ovms.entity.Driver;
import com.cg.ovms.exception.RecordNotFoundException;
import com.cg.ovms.repository.IDriverRepository;

@Service
public class DriverServiceImpl implements DriverService {

	static Logger log = LogManager.getLogger(DriverServiceImpl.class.getName());

	@Autowired
	private IDriverRepository driverRepository;

	@Override
	public Driver addDriver(Driver d) {
		log.info("Add Driver Service Started");
		Driver driver2 = driverRepository.saveAndFlush(d);
		if (d == null || d.getFirstName().length() < 1)
			throw new RecordNotFoundException("Driver record not found");
		log.info("Add Driver Service Ended");
		return driver2;
	}

	@Override
	public List<Driver> getAllDrivers() {
		log.info("View All Drivers Service Started");
		List<Driver> driverList = driverRepository.findAll();
		if (driverList.isEmpty()) {
			throw new RecordNotFoundException("Drivers not found");
		}
		log.info("View All Drivers Service Ended");
		return driverList;
	}

	@Override
	public Driver getDriverById(int id) {
		log.info("View Driver by Id Service Started");
		Optional<Driver> driverOptional = driverRepository.findById(id);
		if (!driverOptional.isPresent()) {
			throw new RecordNotFoundException("Driver record not found");
		}
		log.info("View Driver by Id Service Ended");
		return driverOptional.get();
	}

	@Override
	public Driver updateDriverById(Driver d, int id) {
		log.info("Update Driver Service Started");
		Optional<Driver> driverOptional = driverRepository.findById(id);
		if (!driverOptional.isPresent()) {
			throw new RecordNotFoundException("Driver record not found");
		}
		d.setDriverId(id);
		Driver driver2 = driverRepository.save(d);
		log.info("Update Driver Service Ended");
		return driver2;
	}

	@Override
	public Driver deleteDriverById(int id) {
		log.info("Delete Driver Service Started");
		Optional<Driver> driverOptional = driverRepository.findById(id);
		if (!driverOptional.isPresent()) {
			throw new RecordNotFoundException("Driver record not found");
		}
		driverRepository.deleteById(id);

		log.info("Delete Driver Service Ended");
		return driverOptional.get();
	}
}

package com.cg.ovms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "customer")
public class Customer implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="customer_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer customerId;

	@NotNull(message = "First name cannot be empty.")
	@Column(name="first_name")
	private String firstName;
	
	@NotNull(message = "Last name cannot be empty.")
	@Column(name="last_name")
	private String lastName;
	
	@NotNull
	@Size(min = 10, message = "Mobile number cannot be less than 10 digits.")
	@Column(name="mobile_number")
	private String mobileNumber;
	
	@NotNull
	@Email(regexp = "^[a-zA-Z_].*(@[a-zA-Z]+)(\\.[a-zA-Z]+)$", message = "Please enter a valid email id.")
	@Column(name="email_id", unique=true)
	private String emailId;
	
	@NotNull
	//@Size(min = 15, message = "Address should be a minimum of 15 characters.")
	@Column(name="address")
	private String address;
	
	@JsonIgnore
	@OneToMany(mappedBy = "customer")
	private List<Booking> bookings = new ArrayList<>();
	
	public List<Booking> getBookings() {
		return bookings;
	}

	public void setBookings(List<Booking> bookings) {
		this.bookings = bookings;
	}

	
	
	public Customer(Integer customerId, String firstName,
			String lastName, String mobileNumber, String emailId, String address) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.emailId = emailId;
		this.address = address;
	}

	public Customer() {
		super();
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "CustomerEntity [customerId=" + customerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", mobileNumber=" + mobileNumber + ", emailId=" + emailId + ", address=" + address + ", bookings="
				+ bookings + "]";
	}

}

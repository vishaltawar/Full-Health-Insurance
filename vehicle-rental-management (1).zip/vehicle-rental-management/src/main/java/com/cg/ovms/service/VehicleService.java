package com.cg.ovms.service;

import java.util.List;

import com.cg.ovms.entity.Vehicle;
import com.cg.ovms.exception.RecordNotFoundException;
import com.cg.ovms.exception.SQLException;

public interface VehicleService {

	public Vehicle addVehicle(Vehicle vehicle) throws RecordNotFoundException, SQLException;
	public Vehicle viewVehicle(Vehicle vehicle) throws RecordNotFoundException; 
	public Vehicle updateVehicle(Vehicle vehicle) throws RecordNotFoundException;
	public List<Vehicle> removeVehicle(Integer vehicleId) throws RecordNotFoundException; 
	public List<Vehicle> viewAllVehicle() throws RecordNotFoundException; 
}

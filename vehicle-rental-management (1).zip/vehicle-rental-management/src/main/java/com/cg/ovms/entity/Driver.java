package com.cg.ovms.entity;

import javax.persistence.*;
import javax.validation.constraints.*;

import java.io.Serializable;

@Entity
@Table(name = "driver")
public class Driver implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "driver_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int driverId;

	@NotNull(message = "First name cannot be empty.")
	@Column(name = "first_name")
	private String firstName;

	@NotNull(message = "Last name cannot be empty.")
	@Column(name = "last_name")
	private String lastName;

	@NotNull
	@Size(min = 10, message = "Contact number cannot be less than 10 digits.")
	@Column(name = "contact_number")
	private String contactNumber;

	@NotNull
	@Email(regexp = "^[a-zA-Z_].*(@[a-zA-Z]+)(\\.[a-zA-Z]+)$", message = "Please enter a valid email id.")
	@Column(name = "email")
	private String email;

	@NotNull
	@Column(name = "address")
	private String address;

	@DecimalMax(value = "200.00", message = "Charges per day should not be more than 200.00")
	@Column(name = "charges_per_day")
	private double chargesPerDay;

	@NotNull(message = "License number cannot be empty.")
	@Column(name = "license_number")
	private String licenseNo;

	public Driver() {
		super();
	}

	public Driver(int driverId, String firstName, String lastName, String contactNumber, String email, String address,
			double chargesPerDay, String licenseNo) {
		super();
		this.driverId = driverId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.contactNumber = contactNumber;
		this.email = email;
		this.address = address;
		this.chargesPerDay = chargesPerDay;
		this.licenseNo=licenseNo;
		
	}

	public int getDriverId() {
		return driverId;
	}

	public void setDriverId(int driverId) {
		this.driverId = driverId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getChargesPerDay() {
		return chargesPerDay;
	}

	public void setChargesPerDay(double chargesPerDay) {
		this.chargesPerDay = chargesPerDay;
	}

	public String getLicenseNo() {
		return licenseNo;
	}

	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

	@Override
	public String toString() {
		return "Driver [driverId=" + driverId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", contactNumber=" + contactNumber + ", email=" + email + ", address=" + address + ", chargesPerDay="
				+ chargesPerDay + ", licenseNo=" + licenseNo + "]";
	}
}
package com.cg.ovms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.ovms.entity.Customer;

@Service
public interface CustomerService {

	public Customer addCustomer(Customer customer);
	public Customer removeCustomer(Customer customer);
	public Customer viewCustomer(Customer c);
	public Customer viewCustomerByemailId(String emailId);
	public Customer updateCustomer(Customer c);
	public List<Customer> viewAllCustomer();
	public List<Customer> viewAllCustomersByLocation(String location);
	
}
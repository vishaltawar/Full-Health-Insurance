package com.cg.ovms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ovms.entity.Driver;

public interface IDriverRepository extends JpaRepository<Driver, Integer> {
	
}

package com.cg.ovms.repository;
import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.ovms.entity.Booking;
import com.cg.ovms.entity.Customer;

@Repository
public interface IBookingRepository extends JpaRepository<Booking,Integer> {

	//@Query("SELECT booking FROM Booking booking WHERE booking.booking_date=:byDate")
	public List<Booking> findByBookingDate(@Param("byDate") LocalDate bookingDate);
	
	@Query("SELECT booking FROM Booking booking WHERE booking.customer =:pCustId")
	public List<Booking> getByCustomer(@Param("pCustId") Customer customer);
	
}

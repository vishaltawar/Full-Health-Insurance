package com.cg.ovms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.ovms.entity.Customer;

public interface ICustomerRepository extends JpaRepository<Customer,Integer>{

	public List<Customer> findByAddress(String location);
	
	@Query("SELECT customer FROM Customer customer  WHERE customer.emailId = :email_id")
	public Optional<Customer> findByEmailId(@Param("email_id") String emailId);
	
}
package com.cg.ovms.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ovms.entity.Driver;
import com.cg.ovms.service.DriverServiceImpl;

@CrossOrigin("*")
@RequestMapping("/ovms")
@RestController
public class DriverController {

	static Logger log = LogManager.getLogger(DriverController.class.getName());

	@Autowired
	private DriverServiceImpl driverService;

	@PostMapping("/drivers")
	public Driver addDriver(@RequestBody Driver driver) {
		log.info("Add Driver Controller Started");
		Driver driver2 = driverService.addDriver(driver);
		log.info("Add Driver Controller Stopped");
		return driver2;
	}

	@GetMapping("/drivers")
	public List<Driver> getDrivers() {
		log.info("Get All Drivers Controller Started");
		List<Driver> driverList = driverService.getAllDrivers();
		log.info("Get All Drivers Controller Stopped");
		return driverList;
	}

	@GetMapping("/drivers/{id}")
	public Driver getDriver(@PathVariable int id) {
		log.info("Get Driver by Id Controller Started");
		Driver driver2 = driverService.getDriverById(id);
		log.info("Get Driver by Id Controller Stopped");
		return driver2;
	}

	@PutMapping("/drivers/{id}")
	public Driver updateDriverById(@RequestBody Driver driver, @PathVariable int id) {
		log.info("Update Driver by Id Controller Started");
		Driver driver2 = driverService.updateDriverById(driver, id);
		log.info("Update Driver by Id Controller Stopped");
		return driver2;
	}

	@DeleteMapping("/drivers/{id}")
	public Driver deleteDriverById(@PathVariable int id) {
		log.info("Delete Driver by Id Controller Started");
		Driver driver2 = driverService.deleteDriverById(id);
		log.info("Delete Driver by Id Controller Stopped");
		return driver2;
	}
}

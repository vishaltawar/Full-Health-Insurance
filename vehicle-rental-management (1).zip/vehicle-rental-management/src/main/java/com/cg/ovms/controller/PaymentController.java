package com.cg.ovms.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ovms.entity.Payment;
import com.cg.ovms.exception.RecordNotFoundException;
import com.cg.ovms.service.PaymentService;

@CrossOrigin("*")
@RestController
@RequestMapping("/ovms")
public class PaymentController {
	
	@Autowired
	private PaymentService paymentService;
	
	private static final Logger log = Logger.getLogger(PaymentController.class.getName());
	
	//Calls AddPayment Method from Service Layer
	@PostMapping("/payment")
	public ResponseEntity<Payment> addPayment(@Valid @RequestBody Payment payment) { 			
		
		log.info("Add Payment Controller - Start");
		Payment returnPayment = paymentService.addPayment(payment);
		log.info("Add Payment Controller - Stop");
		
		return new ResponseEntity<>(returnPayment, HttpStatus.OK);
	}

	//Calls cancelPayment Method from Service Layer
	@DeleteMapping("/payment/{paymentId}")
	public ResponseEntity<Payment> cancelPayment(@NotEmpty @PathVariable("paymentId") Integer paymentId) throws RecordNotFoundException {
		
		log.info("Cancel Payment Controller - Start");
		Payment payment = paymentService.cancelPayment(paymentId);
		log.info("Cancel Payment Controller - Stop");
		//return get all payment
		return new ResponseEntity<>(payment, HttpStatus.OK);
	}

	//Calls viewAllPayments Method from Service Layer
	@GetMapping("/payment")
	public ResponseEntity<List<Payment>> viewAllPayments() throws RecordNotFoundException{
		
		log.info("View All Payments Controller - Start");
		List<Payment> paymentList = paymentService.viewAllPayments();
		log.info("View All Payments Controller - Stop");
		
		return new ResponseEntity<>(paymentList, HttpStatus.OK);
	}
	
	//Calls viewPaymentByBooking Method from Service Layer
	@GetMapping("/payment/booking/{bookingId}")
	public ResponseEntity<Payment> viewPaymentByBooking(@PathVariable("bookingId") int bookingId) throws RecordNotFoundException {	
		
		log.info("View Payment By Booking Id Controller - Start");
		Payment payment = paymentService.viewPaymentByBookingId(bookingId);
		log.info("View Payment By Booking Id Controller - Stop");
		
		return new ResponseEntity<>(payment, HttpStatus.OK);
	}
	
	//Validates the input dates. If valid, calls calculateMonthlyRevenue Method from Service Layer
	@GetMapping("/payment/{fromDate}/{tillDate}")
	public ResponseEntity<Double> calculateMonthlyRevenue(@NotEmpty @PathVariable("fromDate") String fromDate, @PathVariable("tillDate") String tillDate) throws ParseException {
		
		log.info("Calculate Monthly Revenue - Start");
		String format = "yyyy-MM-dd";
		Date date1 = new SimpleDateFormat(format).parse(fromDate);
		Date date2 = new SimpleDateFormat(format).parse(tillDate);
		
		Double revenue = paymentService.calculateMonthlyRevenue(date1, date2);
		log.info("Calculate Monthly Revenue - Stop");
		
		return new ResponseEntity<>(revenue, HttpStatus.OK);
	}
	
	@GetMapping("/payment/revenue")
	public ResponseEntity<Double> calculateTotalRevenue() {
		
		log.info("Calculate Total Revenue - Start");
		Double revenue = paymentService.calculateTotalRevenue();
		log.info("Calculate Total Revenue - Stop");
		
		return new ResponseEntity<>(revenue, HttpStatus.OK);
	}
	
	@GetMapping("/payment/customer/{customerId}")
	public ResponseEntity<List<Payment>> viewPaymentByCustomerId(@PathVariable("customerId") int customerId) throws RecordNotFoundException{
		
		log.info("View Payment By Customer Id Controller - Start");
		List<Payment> paymentList = paymentService.viewPaymentByCustomerId(customerId);
		log.info("View Payment By Customer Id Controller - Stop");
		
		return new ResponseEntity<>(paymentList, HttpStatus.OK);
	}
}
package com.cg.ovms.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ovms.OvmsLogger;
import com.cg.ovms.entity.User;
import com.cg.ovms.exception.ApplicationException;
import com.cg.ovms.exception.RecordExistsException;
import com.cg.ovms.exception.RecordNotFoundException;
import com.cg.ovms.exception.UserNotFoundException;
import com.cg.ovms.repository.IUserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private IUserRepository iUserRepository;

	@Override
	public User signIn(User user) throws UserNotFoundException, RecordNotFoundException, RecordExistsException{
		
		OvmsLogger.info("SignIn method invoked in UserServiceImpl.");
		
		if(Objects.isNull(user)) {
			throw new UserNotFoundException("user cannot be null");
		}
		
		Optional<User> user1 = iUserRepository.findById(user.getUserId());

		if(!(user1.isPresent())) {
			OvmsLogger.info("SignIn method unsuccessful - user not found.");
			throw new RecordNotFoundException("Invalid user details");
		}
		
		if(user.getPassword().equals(user1.get().getPassword())) {
			OvmsLogger.info("Password matched correctly - SignIn method successful.");
			return user1.get();
		}
		else {
			OvmsLogger.info("SignIn method unsuccessful - wrong password");
			throw new RecordExistsException("Password Wrong");
		}
	}

	@Override
	public User addUser(User user) throws UserNotFoundException, RecordExistsException, RecordNotFoundException {
		OvmsLogger.info("Adduser method called - adding user...");
		
		if(Objects.isNull(user)) {
			throw new UserNotFoundException("user cannot be null");
		}
		
	    
		Optional<User> user1 = iUserRepository.findById(user.getUserId());
		if(user1.isPresent()) {
			OvmsLogger.info(("Add user method unsuccessful - duplicate user"));
			throw new RecordExistsException("userId already found");
		}
		
		user = iUserRepository.save(user);
		if (user == null) {
			throw new RecordNotFoundException("User Not Added - problem in saving");
		}
		
		OvmsLogger.info("Adduser method executed");
		return user;
	}

	public List<User> getAllUsersInfo(){
		OvmsLogger.info("GetAllUsersInfo method called.");
		
		List<User> userall= iUserRepository.findAll();
		
		OvmsLogger.info("GetAllUsers method executed");
		return userall;
	}

	public User updatePassword(User user, String newPassword) throws ApplicationException, UserNotFoundException{
		if(user==null)
			throw new UserNotFoundException("Invalid User - resend with correct details");
		
		
		Optional<User> user1 = iUserRepository.findById(user.getUserId());
		
		if(!user1.isPresent()) {
			OvmsLogger.info(("Update user method teriminated unsuccessfully - user not found"));
			throw new RecordNotFoundException("User Not Found");
		}
			
		if(user1.get().getPassword().equals(user.getPassword())) {
			user1.get().setPassword(newPassword);
			user = user1.get();
			user = iUserRepository.save(user);
		}

		if (user == null) {
			throw new ApplicationException("Password Updation Unsuccessful");
		}

		return user;
	}

	public User removeUser(User user) throws UserNotFoundException, RecordNotFoundException {
		OvmsLogger.info("RemoveUser method called ");
		
		if(user==null)
			throw new UserNotFoundException("Invalid User - resend with correct details");
		
		
		Optional<User> user1 = iUserRepository.findById(user.getUserId());
		if(!(user1.isPresent())){
			OvmsLogger.info("RemoveUser method unsuccessful - user not found");
			throw new RecordNotFoundException("user is not found");
		}
		
		iUserRepository.delete(user);
		
		OvmsLogger.info("RemoveUser method executed ");

		return user;
	}

	public User signOut(User user) throws RecordNotFoundException, UserNotFoundException {
		OvmsLogger.info("Sign Out method called ");
		if(user==null)
			throw new UserNotFoundException("Invalid User - resend with correct details");
		
		
		Optional<User> user1=iUserRepository.findById(user.getUserId());
		if(!(user1.isPresent())) {
			throw new RecordNotFoundException("User Does Not Exist.");
		}
		if(user.getPassword().equals(user1.get().getPassword())) {
			OvmsLogger.info("Signed Out successfully.");
			return user;
		}
		else {
			throw new RecordNotFoundException("Invalid Details - Password Not Matched");
		}
	}
}
package com.cg.ovms.service;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ovms.entity.Customer;
import com.cg.ovms.repository.ICustomerRepository;
import com.cg.ovms.exception.RecordNotFoundException;

@Service
public class CustomerServiceImpl implements CustomerService {

	static Logger log = Logger.getLogger(CustomerServiceImpl.class.getName());
	
	@Autowired 
	ICustomerRepository customerRepo;
	
	@Override
	public Customer addCustomer(Customer customer) {
		log.info("Service Layer - Entry - addCustomer");
		
		customer = customerRepo.saveAndFlush(customer);
		log.info("Service Layer - Exit - addCustomer");
		return customer;
	}

	@Override
	public Customer removeCustomer(Customer customer) {

		log.info("Service Layer - Entry - removeCustomer");
		
		Optional<Customer> checkCustomer = customerRepo.findById(customer.getCustomerId());
		if(!checkCustomer.isPresent())
		{
			throw new RecordNotFoundException("Record Not Found");
		}
		
		customer = checkCustomer.get();
		customerRepo.delete(customer);					

		
		log.info("Service Layer - Exit - removeCustomer");

		return customer;
	}

	@Override
	public Customer viewCustomer(Customer customer) {
		
		Optional<Customer> repoCustomer = customerRepo.findById(customer.getCustomerId());

		if (repoCustomer.isEmpty()) {
			throw new RecordNotFoundException(" Customer Not Found");
		}

		return repoCustomer.get();
	}
	
	@Override
	public Customer viewCustomerByemailId(String emailId) {
		Optional<Customer> repoCustomer = customerRepo.findByEmailId(emailId);

		if (repoCustomer.isEmpty()) {
			throw new RecordNotFoundException(" Customer Not Found");
		}

		return repoCustomer.get();
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		log.info("Service Layer - Entry - updateCustomer");
		Optional<Customer> checkCustomer = customerRepo.findById(customer.getCustomerId());
		if (checkCustomer.isEmpty()) {
			throw new RecordNotFoundException("Given customer is not found");
		}

		customer = customerRepo.save(customer);
	
		log.info("Service Layer - Exit - updateCustomer");
		return customer;
	}

	@Override
	public List<Customer> viewAllCustomer() {
		log.info("Service Layer - Entry - viewAllCustomer");
		
		List<Customer> customerList = customerRepo.findAll();

		
		if(customerList.isEmpty())
		{
			throw new RecordNotFoundException("No customer found");
		}
		log.info("Service Layer - Exit- viewAllCustomer");
		return customerList;
	}

	@Override
	public List<Customer> viewAllCustomersByLocation(String location) {
		log.info("Service Layer - Entry - viewAllCustomersByLocation");
		
		
		List<Customer> customerList = customerRepo.findByAddress(location);
	
		
		
		if(customerList.isEmpty())
		{
			throw new RecordNotFoundException("No customer found");
		}
		log.info("Service Layer - Exit- viewAllCustomer");
		return customerList;
	}
	

}
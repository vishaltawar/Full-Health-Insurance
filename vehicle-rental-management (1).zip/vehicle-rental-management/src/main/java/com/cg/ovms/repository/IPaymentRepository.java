package com.cg.ovms.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.ovms.entity.Booking;
import com.cg.ovms.entity.Payment;

@Repository
public interface IPaymentRepository extends JpaRepository<Payment, Integer> {

	public Payment findByBooking(Booking booking);
	
	@Query("SELECT payment FROM Payment payment  WHERE payment.paymentDate BETWEEN :date1 AND :date2")
	public List<Payment> getAllBetweenTwoDates(@Param("date1")Date startDate, @Param("date2") Date tillDate);

	@Query("SELECT payment FROM Payment payment  WHERE payment.booking.customer.id = :cust_id")
	public List<Payment> getPaymentByCustomer(@Param("cust_id")int customerID);
	
	@Query("SELECT payment FROM Payment payment  WHERE payment.booking.id = :booking_id")
	public Payment findByBookingId(@Param("booking_id") int bookingId);
}

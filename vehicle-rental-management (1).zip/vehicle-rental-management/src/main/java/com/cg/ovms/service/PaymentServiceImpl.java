package com.cg.ovms.service;

import java.util.*;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ovms.entity.Booking;
import com.cg.ovms.entity.Payment;
import com.cg.ovms.exception.SQLException;
import com.cg.ovms.exception.RecordExistsException;
import com.cg.ovms.exception.RecordNotFoundException;
import com.cg.ovms.repository.IBookingRepository;
import com.cg.ovms.repository.IPaymentRepository;

@Service
public class PaymentServiceImpl implements PaymentService {

	static Logger log = Logger.getLogger(PaymentServiceImpl.class.getName());
	
	@Autowired
	private IPaymentRepository iPaymentRepository;
	
	@Autowired
	private IBookingRepository iBookingRepository;
	
	//If payment with same bookingId exists, throws duplicate record error. Else, saves data to database. 
	//If data is not saved in database, throws database exception. Else, returns data back to controller layer
	@Override
	public Payment addPayment(Payment payment) throws RecordExistsException, SQLException {				
		
		log.info("Add Payment - Start");
		
		if(Objects.isNull(payment))
		{
			throw new SQLException("payment cannot be empty");
		}
		
		
		Payment checkEntity = iPaymentRepository.findByBooking(payment.getBooking());
		if(checkEntity != null) 
		{
			throw new RecordExistsException("payment already exists for this booking");
		} 
		
		iPaymentRepository.saveAndFlush(payment);
		
		Optional<Booking> booking = iBookingRepository.findById(payment.getBooking().getBookingId());
		if(booking.isPresent()) {
			payment.setBooking(booking.get());
		}
		log.info("Add Payment - Stop");
		return payment;
	}

	//If payment with input Id is not found, throws record not found Exception. 
	//If payment with same bookingId exists, throws duplicate record error. Else, saves data to database. 
	//If data is not updated in database, throws database exception. Else, returns data back to controller layer
	@Override
	public Payment cancelPayment(int paymentId) throws RecordNotFoundException {				
		
		log.info("Cancel Payment - Start");
		
		Optional<Payment> optionalPayment= iPaymentRepository.findById(paymentId);
		if(!optionalPayment.isPresent())
		{
			throw new RecordNotFoundException("payment does not exist in database");
		}
		Payment payment = optionalPayment.get();
//		payment.setPaymentStatus("Cancelled");
//		payment.setPaymentMode("None");
//		payment.setPaymentDate(new Date());
		iPaymentRepository.delete(payment);
			
//		payment = iPaymentRepository.save(payment);
		log.info("Cancel Payment - Stop");
		return payment;
	}
	
	//Retrieves all data from database. Throws record not found error if no data found.
	@Override
	public List<Payment> viewAllPayments() {						
	
		log.info("View All Payment - Start");
		
		List<Payment> paymentList = iPaymentRepository.findAll();	
		
		if(paymentList.isEmpty()) 
		{
			throw new RecordNotFoundException("payment data not found");
		}
		
		log.info("View All Payment - Stop");
		
		return paymentList;
	}
		
	//Retrieves single record with input bookingId from database. Throws record not found error if no data found.
	@Override
	public Payment viewPaymentByBookingId(int bookingId) throws RecordNotFoundException {
		
		log.info("View Payment By Booking Id - Start");
		
		Payment payment = iPaymentRepository.findByBookingId(bookingId);
		
		if(Objects.isNull(payment))
		{
			throw new RecordNotFoundException("payment data not found");
		}
		
	
		log.info("View Payment By Booking Id - Stop");
		
		return payment;		
	}
	
	//Retrieves all data from database with paymentDate between the input dates.
	//Throws error if none found
	@Override
	public double calculateMonthlyRevenue(Date date1, Date date2) {		
		
		log.info("Calculate Monthly Revenue - Start");
		
		if(date1 == null || date2 == null)
		{
			throw new SQLException("date cannot be null");
		}
		
		double sum = 0.0;
		List<Payment> resultPaymentList = iPaymentRepository.getAllBetweenTwoDates(date1, date2); 
		
		if(resultPaymentList.isEmpty())
		{
			throw new RecordNotFoundException("no records found");
		}
		for(Payment paymentItr: resultPaymentList)			
		{
			if(paymentItr.getPaymentStatus().equals("Cancelled"))
			{
				log.info(sum);
				sum -= paymentItr.getBooking().getTotalCost();
			}
			sum += paymentItr.getBooking().getTotalCost();
		}
		
		log.info("Calculate Monthly Revenue - Stop");
		
		return sum;
	}

	//Retrieves all data from database with same customer ID.
	@Override
	public List<Payment> viewPaymentByCustomerId(int customerId) throws RecordNotFoundException {
		
		log.info("View Payment By Customer Id - Start");
		
		if(customerId == 0)
		{
			throw new SQLException("customer id cannot be null");
		}
		
		List<Payment> paymentList = iPaymentRepository.getPaymentByCustomer(customerId);
		
		if(paymentList == null)
		{
			throw new RecordNotFoundException("Data not found");
		}
		
		
		log.info("View Payment By Customer Id - Stop");
		
		return paymentList;		
	}
	
	@Override
	public double calculateTotalRevenue() {
		
		log.info("Calculate Total Revenue - Start");
		
		double sum = 0.0;
		List<Payment> resultPaymentList = iPaymentRepository.findAll();
		
		if(resultPaymentList.isEmpty())
		{
			throw new RecordNotFoundException("Records not found");
		}
		
		for(Payment paymentItr: resultPaymentList)			
		{
			if(paymentItr.getPaymentStatus().equals("Cancelled"))
			{
				log.info(sum);
				sum -= paymentItr.getBooking().getTotalCost();
			}
			sum += paymentItr.getBooking().getTotalCost();
		}
		
		log.info("Calculate Total Revenue - Stop");
		
		return sum;
	}
}
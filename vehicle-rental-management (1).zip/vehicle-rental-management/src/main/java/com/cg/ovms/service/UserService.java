package com.cg.ovms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.ovms.entity.User;
import com.cg.ovms.exception.ApplicationException;
import com.cg.ovms.exception.RecordExistsException;
import com.cg.ovms.exception.RecordNotFoundException;
import com.cg.ovms.exception.UserNotFoundException;

@Service
public interface UserService {

	 public User signIn(User user) throws UserNotFoundException, RecordNotFoundException,RecordExistsException;

	 public User addUser(User user) throws UserNotFoundException, RecordNotFoundException, RecordExistsException;

	 public User removeUser(User user) throws UserNotFoundException, RecordNotFoundException;

	 public User updatePassword(User user, String newPassword) throws UserNotFoundException, ApplicationException;

	 public List<User> getAllUsersInfo();

	 public User signOut(User user) throws RecordNotFoundException, UserNotFoundException;

   
}
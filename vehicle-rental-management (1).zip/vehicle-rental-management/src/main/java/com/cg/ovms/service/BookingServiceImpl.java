package com.cg.ovms.service;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ovms.entity.Booking;
import com.cg.ovms.entity.Customer;
import com.cg.ovms.entity.Vehicle;
import com.cg.ovms.exception.SQLException;
import com.cg.ovms.exception.RecordExistsException;
import com.cg.ovms.exception.RecordNotFoundException;
import com.cg.ovms.repository.IBookingRepository;
import com.cg.ovms.repository.ICustomerRepository;
import com.cg.ovms.repository.IVehicleRepository;

@Service
public class BookingServiceImpl implements BookingService{

	private static final Logger log = LogManager.getLogger(BookingServiceImpl.class);
	
	@Autowired
	private IBookingRepository iBookingRepository;
	
	@Autowired
	private IVehicleRepository iVehicleRepository;
	
	@Autowired
	private ICustomerRepository iCustomerRepository;
	
	//adding a new booking
	@Override
	public Booking addBooking(Booking booking) throws SQLException, RecordExistsException {
		log.info("Add Booking Service Started");
		if(Objects.isNull(booking)) {
			throw new SQLException("Booking cannot be null");
		}
		if(!iVehicleRepository.existsById(booking.getVehicle().getVehicleId())) {
			throw new SQLException("Vehicle not found with given vehicle id");
		}
		if(!iCustomerRepository.existsById(booking.getCustomer().getCustomerId())) {
			throw new SQLException("Customer not found with given customer id");
		}
		
		Optional<Vehicle> vehicle = iVehicleRepository.findById(booking.getVehicle().getVehicleId());
		if(vehicle.isPresent()) {
			booking.setVehicle(vehicle.get());
		}
		Optional<Customer> customer = iCustomerRepository.findById(booking.getCustomer().getCustomerId());
		
		if(customer.isPresent()) {
			booking.setCustomer(customer.get());
		}
		int days = findDifference(booking);
		double totalBookingCost = calculatePaymentPerDay(booking, days);
		booking.setTotalCost(totalBookingCost);
		
		if(booking.getBookingId()!=0 && iBookingRepository.existsById(booking.getBookingId())) {

			throw new RecordExistsException("Duplicate Record Found");
		}
		
		iBookingRepository.saveAndFlush(booking);
		Optional<Booking> returnBooking = iBookingRepository.findById(booking.getBookingId());
		if(!returnBooking.isPresent()){
			log.error("exception occurred while adding booking in service layer");
			throw new SQLException("Booking Not Added"); 
		}
		
		log.info("Add Booking Service Ended");
		return returnBooking.get();
	}

	//cancel booking by id
	@Override
	public List<Booking> cancelBooking(Integer bookingId) throws SQLException, RecordNotFoundException{
		
		log.info("Booking Cancellation Service Started");
		
		if(bookingId == null) {
			throw new SQLException("BookingId cannot be 0");
		}
		boolean checkBooking = iBookingRepository.existsById(bookingId);
		if(!checkBooking){
			log.error("exception-cancel booking in service layer");
			throw new RecordNotFoundException("Booking with the given id doesn't exists"); 
		}
		
		iBookingRepository.deleteById(bookingId);
		List<Booking> bookingList = iBookingRepository.findAll();		
		if(bookingList.isEmpty()) {
			log.warn("No bookings avialble after cancelling booking in service layer");
			throw new RecordNotFoundException("No bookings avaliable");
		}
		
		log.info("Booking Cancellation Service Ended");
		return bookingList;
	}

	//Updating a booking
	@Override
	public Booking updateBooking(Booking booking) throws SQLException, RecordNotFoundException{
		log.info("Booking Updation Service Started");
		if(Objects.isNull(booking)) {
			throw new SQLException("Booking cannot be null");
		}
		
		if(!iVehicleRepository.existsById(booking.getVehicle().getVehicleId())){
			throw new SQLException("Vehicle not found with given vehicle id");
		}
		
		if(!iCustomerRepository.existsById(booking.getCustomer().getCustomerId())){
			throw new SQLException("Customer not found with given customer id");
		}
		
		Optional<Vehicle> vehicle = iVehicleRepository.findById(booking.getVehicle().getVehicleId());
		if(vehicle.isPresent()) {
			booking.setVehicle(vehicle.get());
		}
		
		Optional<Customer> customer = iCustomerRepository.findById(booking.getCustomer().getCustomerId());
		if(customer.isPresent()) {
			booking.setCustomer(customer.get());
		}
		int days = findDifference(booking);
		
		double totalBookingCost = calculatePaymentPerDay(booking, days);
		booking.setTotalCost(totalBookingCost);
		
		Boolean checkBooking =iBookingRepository.existsById(booking.getBookingId());
		if(!checkBooking){
			log.error("exception-update booking in service layer");
			throw new RecordNotFoundException("Booking with the given id doesn't exist"); 
		}
		
		
		iBookingRepository.save(booking);
		
		Optional<Booking> returnBooking =iBookingRepository.findById(booking.getBookingId());
		
		if(!returnBooking.isPresent()){
			log.error("exception-couldnot add updated booking in service layer");
			throw new SQLException("Booking updation did not happened"); 
		}
		
		log.info("Booking Updation Service Ended");
		return returnBooking.get();
	}

	//view all bookings
	@Override
	public List<Booking> viewAllBookings() throws RecordNotFoundException{
		
		log.info("View All Bookings Service Started");
			
		List<Booking> bookingList= iBookingRepository.findAll();
		if(bookingList.isEmpty()){
			log.error("Exception- No bookings in service layer");
			throw new RecordNotFoundException("No Bookings Found");
		}
		
		log.info("View All Bookings Service Ended");
		return bookingList;
		
	}
	
	//view booking by booking id
	@Override
	public Booking viewBookingById(Integer bookingId) throws SQLException, RecordNotFoundException{
		log.info("View Booking by Booking Id Service Started");
		if(bookingId == null) {
			throw new SQLException("Booking Id cannot be null"); 
		}
		
		Optional<Booking> returnBooking =iBookingRepository.findById(bookingId);
		
		if(!returnBooking.isPresent()){
			log.error("exception-view bookingById in service layer");
			throw new RecordNotFoundException("Booking with the given id not found");
		}
			
		log.info("View Booking by Booking Id Service Ended");
		return returnBooking.get();

	}
	
	//view all bookings by customer id
	@Override
	public List<Booking> viewAllBookingByCustomer(Integer customerId) throws SQLException, RecordNotFoundException{
		log.info("View All Booking By Customer Id Service Started");
		if(customerId == null) {
			throw new SQLException("Customer Id cannot be null");
		}
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		
		List<Booking> bookingList= iBookingRepository.getByCustomer(customer);
		if(bookingList == null || bookingList.isEmpty()){
			log.error("exception-No booking by given customer in service layer");
			throw new RecordNotFoundException("Booking with given cutomer id not found");
		}
		
		log.info("View All Booking By Customer Id Service Ended");
		return bookingList;
	}
	
	//view bookings by booking date
	@Override
	public List<Booking> viewAllBookingByDate(String bookingDate) throws SQLException, RecordNotFoundException{
		log.info("View All Booking By Date Service Started");
		if(bookingDate == null) {
			throw new SQLException("Date Cannot be null");
		}
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate localBookingDate = LocalDate.parse(bookingDate, formatter);
		
		List<Booking> bookingList=iBookingRepository.findByBookingDate(localBookingDate);
		if(bookingList == null || bookingList.isEmpty()){
			log.error("Exception - No booking on given date in service layer");
			throw new RecordNotFoundException("Booking with given date not found");
		}
		
		log.info("View All Booking By Date Service Ended");
		return bookingList;
		
	}
	
	public double calculatePaymentPerDay(Booking booking, int days) 
	{
		log.info("Calculating Payment");
		double driverCharge = booking.getVehicle().getDriver().getChargesPerDay();
		double fixedCharge = booking.getVehicle().getFixedCharges();
		double chargePerKM = booking.getVehicle().getChargesPerKM();
		double distance = booking.getDistance();
		double charge = (driverCharge*days) + fixedCharge + (distance*chargePerKM); 
		log.info("Payment Calculation Done");
		return charge;
		
	}
	
	public int findDifference(Booking booking){ 
		
		Period diff = Period.between(booking.getBookingDate(),booking.getBookedTillDate()); 
		int days = diff.getDays() + diff.getMonths()*30 + diff.getYears()*365;
		if(days == 0) {
			days = 1;
		}
		
		return days;
	}
}
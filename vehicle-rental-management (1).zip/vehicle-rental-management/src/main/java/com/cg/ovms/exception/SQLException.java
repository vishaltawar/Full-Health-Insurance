package com.cg.ovms.exception;

public class SQLException  extends RuntimeException
{
	private static final long serialVersionUID = 1L;
	
	public SQLException(String msg) {
       super(msg);
	}
}


package com.example.Trainee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TraineeLab2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
